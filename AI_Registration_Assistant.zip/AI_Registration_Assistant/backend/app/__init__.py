# AI Registration Assistant Backend
# This package contains the FastAPI application for the AI Registration Assistant
